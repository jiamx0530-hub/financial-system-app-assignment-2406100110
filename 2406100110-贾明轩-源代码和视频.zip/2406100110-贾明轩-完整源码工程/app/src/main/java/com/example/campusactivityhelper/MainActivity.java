package com.example.campusactivityhelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends Activity {
    public static final String EXTRA_NAME = "extra_name";
    public static final String EXTRA_PHONE = "extra_phone";
    public static final String EXTRA_TYPE = "extra_type";
    public static final String EXTRA_TIME = "extra_time";
    public static final String EXTRA_NEEDS = "extra_needs";

    private EditText editParticipantName;
    private EditText editPhone;
    private Spinner spinnerActivityType;
    private RadioGroup radioGroupTime;
    private CheckBox checkReminder;
    private CheckBox checkVolunteerCertificate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editParticipantName = findViewById(R.id.editParticipantName);
        editPhone = findViewById(R.id.editPhone);
        spinnerActivityType = findViewById(R.id.spinnerActivityType);
        radioGroupTime = findViewById(R.id.radioGroupTime);
        checkReminder = findViewById(R.id.checkReminder);
        checkVolunteerCertificate = findViewById(R.id.checkVolunteerCertificate);
        ImageButton buttonReset = findViewById(R.id.buttonReset);
        Button buttonSubmit = findViewById(R.id.buttonSubmit);
        ListView listNotice = findViewById(R.id.listNotice);

        ArrayAdapter<CharSequence> typeAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.activity_types,
                android.R.layout.simple_spinner_item
        );
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerActivityType.setAdapter(typeAdapter);

        String[] notices = {
                "1. 请填写真实联系方式",
                "2. 报名后请按时到场签到",
                "3. 如需取消，请提前联系负责人"
        };
        listNotice.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                notices
        ));

        buttonReset.setOnClickListener(v -> resetForm());
        buttonSubmit.setOnClickListener(v -> submitForm());
    }

    private void resetForm() {
        editParticipantName.setText("");
        editPhone.setText("");
        spinnerActivityType.setSelection(0);
        radioGroupTime.check(R.id.radioMorning);
        checkReminder.setChecked(false);
        checkVolunteerCertificate.setChecked(false);
        editParticipantName.requestFocus();
        Toast.makeText(this, "表单已清空", Toast.LENGTH_SHORT).show();
    }

    private void submitForm() {
        String name = editParticipantName.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            editParticipantName.setError("请输入参加者姓名");
            editParticipantName.requestFocus();
            return;
        }
        if (!phone.matches("1\\d{10}")) {
            editPhone.setError("请输入正确的 11 位手机号码");
            editPhone.requestFocus();
            return;
        }

        String activityType = spinnerActivityType.getSelectedItem().toString();
        String time = radioGroupTime.getCheckedRadioButtonId() == R.id.radioAfternoon
                ? "下午场" : "上午场";

        StringBuilder needsBuilder = new StringBuilder();
        if (checkReminder.isChecked()) {
            needsBuilder.append("活动提醒");
        }
        if (checkVolunteerCertificate.isChecked()) {
            if (needsBuilder.length() > 0) {
                needsBuilder.append("、");
            }
            needsBuilder.append("电子参与证明");
        }
        String needs = needsBuilder.length() == 0 ? "无" : needsBuilder.toString();

        Intent intent = new Intent(MainActivity.this, ConfirmationActivity.class);
        intent.putExtra(EXTRA_NAME, name);
        intent.putExtra(EXTRA_PHONE, phone);
        intent.putExtra(EXTRA_TYPE, activityType);
        intent.putExtra(EXTRA_TIME, time);
        intent.putExtra(EXTRA_NEEDS, needs);
        startActivity(intent);
    }
}
