package com.example.campusactivityhelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class ConfirmationActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        TextView textWelcome = findViewById(R.id.textWelcome);
        ListView listSummary = findViewById(R.id.listSummary);
        Button buttonBack = findViewById(R.id.buttonBack);

        Intent intent = getIntent();
        String name = intent.getStringExtra(MainActivity.EXTRA_NAME);
        String phone = intent.getStringExtra(MainActivity.EXTRA_PHONE);
        String activityType = intent.getStringExtra(MainActivity.EXTRA_TYPE);
        String time = intent.getStringExtra(MainActivity.EXTRA_TIME);
        String needs = intent.getStringExtra(MainActivity.EXTRA_NEEDS);

        textWelcome.setText("报名信息已生成，" + safe(name) + "同学请核对");

        String[] summaryItems = {
                "参加者：" + safe(name),
                "联系电话：" + safe(phone),
                "活动类型：" + safe(activityType),
                "参加时段：" + safe(time),
                "附加需求：" + safe(needs)
        };
        listSummary.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                summaryItems
        ));

        buttonBack.setOnClickListener(v -> finish());
    }

    private String safe(String value) {
        return value == null ? "未填写" : value;
    }
}
